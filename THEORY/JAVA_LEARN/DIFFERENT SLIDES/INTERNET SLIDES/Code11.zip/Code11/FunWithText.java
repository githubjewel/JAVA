/*
 * File: FunWithText.java
 * ================================================================
 * A program where we have fun with text!
 */
import acm.program.*;

public class FunWithText extends ConsoleProgram {
	/* Time to pause between characters. */
	private static final double PAUSE_TIME = 75;
	
	/**
	 * Prints a string one character at a time.
	 * 
	 * @param text The text to print.
	 */
	private void printCharByChar(String text) {
		for (int i = 0; i < text.length(); i++) {
			char current = text.charAt(i);
			
			/* Print the current character and delay long enough to
			 * have the effect of characters printing one at a time.
			 */
			print(current);
			pause(PAUSE_TIME);
		}
		
		/* Print a newline after everything. */
		println();
	}
	
	public void run() {
		setFont("UbuntuMono-26-BOLD");
		
		/* Read a noun and a description. */
		String noun = readLine("Enter a noun: ");
		String desc = readLine("Enter a description: ");
		
		/* Build up a description of the noun. */
		String result = "The " + noun + " is " + desc + ".";
		
		/* Print it... slowly. */
		printCharByChar(result);
	}
}